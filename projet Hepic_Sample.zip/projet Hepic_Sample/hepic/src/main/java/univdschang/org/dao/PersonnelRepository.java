package univdschang.org.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import univdschang.org.entities.Personnel;

public interface PersonnelRepository extends JpaRepository<Personnel, Long> {

}
