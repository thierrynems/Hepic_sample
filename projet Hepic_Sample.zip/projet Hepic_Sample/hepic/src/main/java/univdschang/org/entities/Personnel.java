package univdschang.org.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Personnel implements Serializable {

	 //attribut du personnel 
	@Id 
	@GeneratedValue
	private Long idpersonnel;
	private String matricule; 
	private String nompersonnel;
	private String prenompersonnel;
	private String cnipersonnel;
	@Temporal(TemporalType.DATE)
	private  Date datenaissance;
	private String lieunaissance;
	private String sexe;
	private String email;
	private long telephone;
	//getters and setters
	public Long getIdpersonnel() {
		return idpersonnel;
	}
	public void setIdpersonnel(Long idpersonnel) {
		this.idpersonnel = idpersonnel;
	}
	public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
	public String getNompersonnel() {
		return nompersonnel;
	}
	public void setNompersonnel(String nompersonnel) {
		this.nompersonnel = nompersonnel;
	}
	public String getPrenompersonnel() {
		return prenompersonnel;
	}
	public void setPrenompersonnel(String prenompersonnel) {
		this.prenompersonnel = prenompersonnel;
	}
	public String getCnipersonnel() {
		return cnipersonnel;
	}
	public void setCnipersonnel(String cnipersonnel) {
		this.cnipersonnel = cnipersonnel;
	}
	public Date getDatenaissance() {
		return datenaissance;
	}
	public void setDatenaissance(Date datenaissance) {
		this.datenaissance = datenaissance;
	}
	public String getLieunaissance() {
		return lieunaissance;
	}
	public void setLieunaissance(String lieunaissance) {
		this.lieunaissance = lieunaissance;
	}
	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getTelephone() {
		return telephone;
	}
	public void setTelephone(long telephone) {
		this.telephone = telephone;
	}
	public Personnel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Personnel(String matricule, String nompersonnel,
			String prenompersonnel, String cnipersonnel, Date datenaissance,
			String lieunaissance, String sexe, String email, long telephone) {
		super();
		this.matricule = matricule;
		this.nompersonnel = nompersonnel;
		this.prenompersonnel = prenompersonnel;
		this.cnipersonnel = cnipersonnel;
		this.datenaissance = datenaissance;
		this.lieunaissance = lieunaissance;
		this.sexe = sexe;
		this.email = email;
		this.telephone = telephone;
	}
	
}
