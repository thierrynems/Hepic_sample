package univdschang.org.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import univdschang.org.dao.PersonnelRepository;
import univdschang.org.entities.Personnel;

@RestController
@CrossOrigin("*")
public class PersonnelRestService {
	@Autowired
  private PersonnelRepository personnelRepository;
	//====get List personnel ============
	@RequestMapping(value="/personnel",method=RequestMethod.GET)
	public List<Personnel> getPersonnel(){
		return personnelRepository.findAll();
	}
	//====get One personnel ============
	@RequestMapping(value="/personnel/{idpersonnel}",method=RequestMethod.GET)
	public Personnel getPersonnel(@PathVariable Long idpersonnel){
		return personnelRepository.findOne(idpersonnel);
	}
	//===============Save Personnel ================== 
	@RequestMapping(value="/personnel",method=RequestMethod.POST)
	public Personnel save(@RequestBody Personnel pers){
		return personnelRepository.save(pers); 
	}
	
	//==============Delete Personnel ================
	@RequestMapping(value="/personnel/{idpersonnel}",method=RequestMethod.DELETE)
	public boolean delete(@PathVariable Long idpersonnel){
		personnelRepository.delete(idpersonnel);
		 return true;
	}
	//============Update Personnel ======================
	@RequestMapping(value="/personnel/{idpersonnel}",method=RequestMethod.PUT)
	public Personnel update(@PathVariable Long idpersonnel, @RequestBody Personnel pers){
		pers.setIdpersonnel(idpersonnel);
		return personnelRepository.save(pers);
	}
}
