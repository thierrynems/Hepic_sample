package univdschang.org.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import univdschang.org.entities.Institution;

public interface InstitutionRepository extends JpaRepository<Institution, Long> {

}
