package univdschang.org.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;

@Entity
public class Institution implements Serializable {
 @Id
 @GeneratedValue
 private Long idInstitution;
 private String codeinstitution;
 private String libelleinstitution;
 private String localisation;
 private long telephone;
 private String email;
 private String siteweb;
public Long getIdInstitution() {
	return idInstitution;
}
public void setIdInstitution(Long idInstitution) {
	this.idInstitution = idInstitution;
}
public String getCodeinstitution() {
	return codeinstitution;
}
public void setCodeinstitution(String codeinstitution) {
	this.codeinstitution = codeinstitution;
}
public String getLibelleinstitution() {
	return libelleinstitution;
}
public void setLibelleinstitution(String libelleinstitution) {
	this.libelleinstitution = libelleinstitution;
}
public String getLocalisation() {
	return localisation;
}
public void setLocalisation(String localisation) {
	this.localisation = localisation;
}
public long getTelephone() {
	return telephone;
}
public void setTelephone(long telephone) {
	this.telephone = telephone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getSiteweb() {
	return siteweb;
}
public void setSiteweb(String siteweb) {
	this.siteweb = siteweb;
}
public Institution() {
	super();
	// TODO Auto-generated constructor stub
}
public Institution(String codeinstitution, String libelleinstitution,
		String localisation, long telephone, String email, String siteweb) {
	super();
	this.codeinstitution = codeinstitution;
	this.libelleinstitution = libelleinstitution;
	this.localisation = localisation;
	this.telephone = telephone;
	this.email = email;
	this.siteweb = siteweb;
}
 

}
