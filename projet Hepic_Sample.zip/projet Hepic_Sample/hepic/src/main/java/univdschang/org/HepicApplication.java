package univdschang.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HepicApplication {

	public static void main(String[] args) {
		SpringApplication.run(HepicApplication.class, args);
	}
}
