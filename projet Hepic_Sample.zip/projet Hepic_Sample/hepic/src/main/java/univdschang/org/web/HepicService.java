package univdschang.org.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import univdschang.org.dao.InstitutionRepository;
import univdschang.org.entities.Institution;
 

@RestController
@CrossOrigin("*")
public class HepicService {
 @Autowired
 private InstitutionRepository institionRepository;
 //==================get liste institution ===================
 @RequestMapping(value="/institution",method=RequestMethod.GET)
 public List<Institution> getListeInstitution(){
	return institionRepository.findAll(); 
 }
 //================== get one institution by id ===============
 @RequestMapping(value="/institution/{idinstition}", method=RequestMethod.GET)
 Institution getOneInstitution(Long idInstitution){
	 return institionRepository.findOne(idInstitution);
 }
 
}
