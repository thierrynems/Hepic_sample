import { Injectable } from "@angular/core";
import { Http, Response } from "@angular/http";

@Injectable()
export class PersonnelService{
    private apiUrl="http://localhost:8080/personnel";

    constructor(private http:Http){

    }
    //=============liste des personnels 
    getListePersonnel(){
        return this.http.get(this.apiUrl)
        .map((res:Response)=>res.json())
       }
}