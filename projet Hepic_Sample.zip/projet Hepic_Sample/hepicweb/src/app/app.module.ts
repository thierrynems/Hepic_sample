import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PersonnelComponent } from './personnel/personnel.component';
import {Routes, RouterModule} from "@angular/router";
import { AccueilComponent } from './accueil/accueil.component';
import { HttpModule } from '@angular/http';
import { PersonnelService } from '../services/personnel.service';
const appRoutes:Routes=[
  {path: 'accueil', component:AccueilComponent},
  {path: 'personnel', component:PersonnelComponent},
  {path:'',redirectTo:'accueil',pathMatch:'full'}
];
@NgModule({
  declarations: [
    AppComponent,
    PersonnelComponent,
    AccueilComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),HttpModule
  ],
  providers: [PersonnelService],
  bootstrap: [AppComponent]
})
export class AppModule { }
