import { Component, OnInit } from '@angular/core';
import { Http} from '@angular/http';
import "rxjs/add/operator/map";
import { PersonnelService } from '../../services/personnel.service';
//import { map } from 'rxjs/operators';
@Component({
  selector: 'app-personnel',
  templateUrl: './personnel.component.html',
  styleUrls: ['./personnel.component.css']
})
//implements OnInit
export class PersonnelComponent  {
   
  personnel:any;
   
  constructor(private http:Http, public personnelservice: PersonnelService) {
     this.personnelservice.getListePersonnel()
     .subscribe(data=>{
      console.log(data);
      this.personnel=data
    }); 
   
  }

}
